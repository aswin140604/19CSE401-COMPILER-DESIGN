# Lex-Programs


| Name    | Nehal Khan |
| -------- | ------- |
| Roll No  | CH.EN.U4CSE22041    |

<img width="734" height="429" alt="image" src="https://github.com/user-attachments/assets/cc9b1025-4070-432e-9ce6-254a68126b58" />



